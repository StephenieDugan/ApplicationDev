﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rise_of_the_Neu_Republic.Utilities
{
    internal class DialogueManager
    {
        public string CurrentDialogue { get; private set; }
        public List<string> CurrentOptions { get; private set; }

    }
}
