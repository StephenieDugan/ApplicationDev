
using Rise_of_the_Neu_Republic.Utilities;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using System.Windows.Forms;

namespace ApplicationDev
{

    public partial class DialogueForm : Form
    {
        Player playerCharacter;
        Enemy enemyCharacter;
        public DialogueForm(Player player, Enemy enemy)
        {
            playerCharacter = player;
            enemyCharacter = enemy;
            InitializeComponent();
            lblStrength.Text = playerCharacter.Strength.ToString();
            lblAgility.Text = playerCharacter.Agility.ToString();
            lblIntel.Text = playerCharacter.Intelligence.ToString();
            lblDex.Text = playerCharacter.Dexterity.ToString();
            lblConst.Text = playerCharacter.Constitution.ToString();
            lblRiz.Text = playerCharacter.Charisma.ToString();

        }
        private void btnOption1_Click(object sender, EventArgs e)
        {
            //Handle option 1
            enemyCharacter.monsterIndex = 0;
            this.Close();
        }
        private void btnOption2_Click(object sender, EventArgs e)
        {
            //handle option 2
            enemyCharacter.monsterIndex = 1;
            this.Close();
        }

        // Add more event handlers as needed
    }
}