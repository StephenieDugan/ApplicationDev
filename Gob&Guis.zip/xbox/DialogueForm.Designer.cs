﻿namespace ApplicationDev;

partial class DialogueForm
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        btnOption1 = new Button();
        btnOption2 = new Button();
        lblDialogue = new Label();
        lblRiz = new Label();
        lblConst = new Label();
        lblDex = new Label();
        lblIntel = new Label();
        lblAgility = new Label();
        lblStrength = new Label();
        lblNameRiz = new Label();
        lblNameConst = new Label();
        lblNameDex = new Label();
        lblNameIntel = new Label();
        lblNameAgility = new Label();
        lblNameStrength = new Label();
        label1 = new Label();
        SuspendLayout();
        // 
        // btnOption1
        // 
        btnOption1.Location = new Point(118, 58);
        btnOption1.Name = "btnOption1";
        btnOption1.Size = new Size(112, 34);
        btnOption1.TabIndex = 0;
        btnOption1.Text = "Skeleton";
        btnOption1.UseVisualStyleBackColor = true;
        btnOption1.Click += btnOption1_Click;
        // 
        // btnOption2
        // 
        btnOption2.Location = new Point(334, 58);
        btnOption2.Name = "btnOption2";
        btnOption2.Size = new Size(112, 34);
        btnOption2.TabIndex = 1;
        btnOption2.Text = "Slime";
        btnOption2.UseVisualStyleBackColor = true;
        btnOption2.Click += btnOption2_Click;
        // 
        // lblDialogue
        // 
        lblDialogue.AutoSize = true;
        lblDialogue.Location = new Point(109, 147);
        lblDialogue.Name = "lblDialogue";
        lblDialogue.Size = new Size(154, 25);
        lblDialogue.TabIndex = 2;
        lblDialogue.Text = "Welcome Traveler!";
        // 
        // lblRiz
        // 
        lblRiz.AutoSize = true;
        lblRiz.Location = new Point(680, 163);
        lblRiz.Name = "lblRiz";
        lblRiz.Size = new Size(22, 25);
        lblRiz.TabIndex = 27;
        lblRiz.Text = "0";
        // 
        // lblConst
        // 
        lblConst.AutoSize = true;
        lblConst.Location = new Point(680, 138);
        lblConst.Name = "lblConst";
        lblConst.Size = new Size(22, 25);
        lblConst.TabIndex = 26;
        lblConst.Text = "0";
        // 
        // lblDex
        // 
        lblDex.AutoSize = true;
        lblDex.Location = new Point(680, 113);
        lblDex.Name = "lblDex";
        lblDex.Size = new Size(22, 25);
        lblDex.TabIndex = 25;
        lblDex.Text = "0";
        // 
        // lblIntel
        // 
        lblIntel.AutoSize = true;
        lblIntel.Location = new Point(680, 88);
        lblIntel.Name = "lblIntel";
        lblIntel.Size = new Size(22, 25);
        lblIntel.TabIndex = 24;
        lblIntel.Text = "0";
        // 
        // lblAgility
        // 
        lblAgility.AutoSize = true;
        lblAgility.Location = new Point(680, 63);
        lblAgility.Name = "lblAgility";
        lblAgility.Size = new Size(22, 25);
        lblAgility.TabIndex = 23;
        lblAgility.Text = "0";
        // 
        // lblStrength
        // 
        lblStrength.AutoSize = true;
        lblStrength.Location = new Point(680, 38);
        lblStrength.Name = "lblStrength";
        lblStrength.Size = new Size(22, 25);
        lblStrength.TabIndex = 22;
        lblStrength.Text = "0";
        // 
        // lblNameRiz
        // 
        lblNameRiz.AutoSize = true;
        lblNameRiz.Location = new Point(560, 163);
        lblNameRiz.Name = "lblNameRiz";
        lblNameRiz.Size = new Size(85, 25);
        lblNameRiz.TabIndex = 21;
        lblNameRiz.Text = "Charisma";
        // 
        // lblNameConst
        // 
        lblNameConst.AutoSize = true;
        lblNameConst.Location = new Point(560, 138);
        lblNameConst.Name = "lblNameConst";
        lblNameConst.Size = new Size(109, 25);
        lblNameConst.TabIndex = 20;
        lblNameConst.Text = "Constitution";
        // 
        // lblNameDex
        // 
        lblNameDex.AutoSize = true;
        lblNameDex.Location = new Point(560, 113);
        lblNameDex.Name = "lblNameDex";
        lblNameDex.Size = new Size(82, 25);
        lblNameDex.TabIndex = 19;
        lblNameDex.Text = "Dexterity";
        // 
        // lblNameIntel
        // 
        lblNameIntel.AutoSize = true;
        lblNameIntel.Location = new Point(558, 88);
        lblNameIntel.Name = "lblNameIntel";
        lblNameIntel.Size = new Size(101, 25);
        lblNameIntel.TabIndex = 18;
        lblNameIntel.Text = "Intelligence";
        // 
        // lblNameAgility
        // 
        lblNameAgility.AutoSize = true;
        lblNameAgility.Location = new Point(558, 63);
        lblNameAgility.Name = "lblNameAgility";
        lblNameAgility.Size = new Size(62, 25);
        lblNameAgility.TabIndex = 17;
        lblNameAgility.Text = "Agility";
        // 
        // lblNameStrength
        // 
        lblNameStrength.AutoSize = true;
        lblNameStrength.Location = new Point(560, 38);
        lblNameStrength.Name = "lblNameStrength";
        lblNameStrength.Size = new Size(79, 25);
        lblNameStrength.TabIndex = 16;
        lblNameStrength.Text = "Strength";
        // 
        // label1
        // 
        label1.AutoSize = true;
        label1.Location = new Point(558, 9);
        label1.Name = "label1";
        label1.Size = new Size(72, 25);
        label1.TabIndex = 15;
        label1.Text = "STATUS";
        // 
        // DialogueForm
        // 
        AutoScaleDimensions = new SizeF(10F, 25F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(722, 314);
        Controls.Add(lblRiz);
        Controls.Add(lblConst);
        Controls.Add(lblDex);
        Controls.Add(lblIntel);
        Controls.Add(lblAgility);
        Controls.Add(lblStrength);
        Controls.Add(lblNameRiz);
        Controls.Add(lblNameConst);
        Controls.Add(lblNameDex);
        Controls.Add(lblNameIntel);
        Controls.Add(lblNameAgility);
        Controls.Add(lblNameStrength);
        Controls.Add(label1);
        Controls.Add(lblDialogue);
        Controls.Add(btnOption2);
        Controls.Add(btnOption1);
        Name = "DialogueForm";
        Text = "Dialogue Form";
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion


    private Button btnOption1;
    private Button btnOption2;
    private Label lblDialogue;
    private Label lblRiz;
    private Label lblConst;
    private Label lblDex;
    private Label lblIntel;
    private Label lblAgility;
    private Label lblStrength;
    private Label lblNameRiz;
    private Label lblNameConst;
    private Label lblNameDex;
    private Label lblNameIntel;
    private Label lblNameAgility;
    private Label lblNameStrength;
    private Label label1;
}
