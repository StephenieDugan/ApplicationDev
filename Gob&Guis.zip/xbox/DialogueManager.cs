﻿using Rise_of_the_Neu_Republic.Utilities;

namespace ApplicationDev
{
    internal class DialogueManager
    {
        public string CurrentDialogueText { get; private set; }

        public void LoadDialogue(int dialogueID)
        {
            // Load dialogue based on ID and set CurrentDialogueText
        }
    }
}
