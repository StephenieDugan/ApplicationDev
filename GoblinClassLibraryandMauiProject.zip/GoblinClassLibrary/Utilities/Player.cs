﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoblinClassLibrary
{
    public class Player : Character
    {
        public bool hasSword { get; set; }
        public bool hasShield { get; set; }

    }
}
