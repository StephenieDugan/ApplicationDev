namespace MauiAppGobs;
using Microsoft.Maui.Controls;
public partial class DialoguePage : ContentPage
{
	public DialoguePage()
	{
		InitializeComponent();
	}

    private void OnDialogueClick(object sender, EventArgs e)
    {
       
    }
}