
using GoblinClassLibrary;

using Microsoft.Maui.Controls;
namespace MauiAppGobs;

	public partial class CombatPage : ContentPage
	{
		public CombatPage()
		{
			InitializeComponent();
		}

        private void OnCastSpellClick(object sender, EventArgs e)
        {
            
        }
    }
